﻿from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import sys
import os

# Thêm đường dẫn để import các file từ /opt/airflow/app
sys.path.append("/opt/airflow/app")

from crawl import crawl_cat_data
from transform import transform_cat_data
from save import save_cat_data

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=1)
}

with DAG(
    dag_id='cat_pipeline',
    default_args=default_args,
    description='DAG crawl -> transform -> save cat data',
    schedule_interval='0 9 * * *',  # Chạy lúc 9h sáng mỗi ngày
    start_date=datetime(2025, 4, 10),
    catchup=False
) as dag:

    task_crawl = PythonOperator(
        task_id='crawl_cat',
        python_callable=crawl_cat_data
    )

    task_transform = PythonOperator(
        task_id='transform_cat',
        python_callable=transform_cat_data
    )

    task_save = PythonOperator(
        task_id='save_cat',
        python_callable=save_cat_data
    )

    task_crawl >> task_transform >> task_save
