﻿import requests
import json

def crawl_cat_breeds(output_file='cat_breeds_raw.json'):
    url = 'https://api.thecatapi.com/v1/breeds'
    response = requests.get(url)

    if response.status_code == 200:
        breeds = response.json()
        extracted_data = []

        for breed in breeds:
            data = {
                'id': breed.get('id'),
                'name': breed.get('name'),
                'origin': breed.get('origin'),
                'temperament': breed.get('temperament'),
                'life_span': breed.get('life_span'),
                'image_url': breed.get('image', {}).get('url')  # tránh lỗi nếu không có ảnh
            }
            extracted_data.append(data)

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(extracted_data, f, ensure_ascii=False, indent=2)

        print(f'Đã lưu {len(extracted_data)} giống mèo vào {output_file}')
    else:
        print(f'Lỗi khi gọi API: {response.status_code}')

def crawl_cat_data():
    crawl_cat_breeds()
