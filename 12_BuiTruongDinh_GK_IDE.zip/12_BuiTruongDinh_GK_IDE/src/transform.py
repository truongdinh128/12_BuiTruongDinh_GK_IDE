﻿import json

DEFAULT_IMAGE_URL = "https://cdn2.thecatapi.com/images/aae.jpg"

def clean_cat_breeds(input_file='cat_breeds_raw.json', output_file='cat_breeds_clean.json'):
    with open(input_file, 'r', encoding='utf-8') as f:
        raw_data = json.load(f)

    cleaned_data = []
    for item in raw_data:
        cleaned_item = {
            'id': item.get('id'),
            'name': item.get('name'),
            'origin': item.get('origin'),
            'life_span': item.get('life_span'),
            'temperament': [trait.strip() for trait in item.get('temperament', '').split(',') if trait.strip()],
            'image_url': item.get('image_url') or DEFAULT_IMAGE_URL
        }
        cleaned_data.append(cleaned_item)

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(cleaned_data, f, ensure_ascii=False, indent=2)

    print(f'Đã làm sạch và lưu {len(cleaned_data)} giống mèo vào {output_file}')

def transform_cat_data():
    clean_cat_breeds()
