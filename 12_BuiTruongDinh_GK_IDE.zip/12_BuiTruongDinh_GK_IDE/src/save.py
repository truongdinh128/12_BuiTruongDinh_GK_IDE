﻿import os
import json
import psycopg2
import requests

DATA_FILE = 'cat_breeds_clean.json'
IMAGE_DIR = '../data/images'
DEFAULT_IMAGE_URL = "https://cdn2.thecatapi.com/images/aae.jpg"

DB_CONFIG = {
    'host': 'postgres',
    'port': 5432,
    'dbname': 'newsdb',
    'user': 'airflow',
    'password': 'airflow'
}

def create_table(conn):
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS cat_breeds (
                id TEXT PRIMARY KEY,
                name TEXT,
                origin TEXT,
                temperament TEXT[],
                life_span TEXT,
                image_url TEXT
            );
        """)
        conn.commit()

def insert_data(conn, data):
    with conn.cursor() as cur:
        for item in data:
            cur.execute("""
                INSERT INTO cat_breeds (id, name, origin, temperament, life_span, image_url)
                VALUES (%s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO NOTHING;
            """, (
                item['id'],
                item['name'],
                item['origin'],
                item['temperament'],
                item['life_span'],
                item['image_url']
            ))
        conn.commit()

def download_image(id, url):
    image_path = os.path.join(IMAGE_DIR, f"{id}.jpg")
    if os.path.exists(image_path):
        return

    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            with open(image_path, 'wb') as f:
                f.write(response.content)
            print(f"Tải ảnh {id} thành công.")
        else:
            print(f"Lỗi tải ảnh {id}: {response.status_code}")
    except Exception as e:
        print(f"Không thể tải ảnh {id}: {e}")

def main():


    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Kết nối DB
    conn = psycopg2.connect(**DB_CONFIG)

    # Tạo bảng nếu chưa có
    create_table(conn)

    # Chèn metadata
    insert_data(conn, data)

    # Tải tối đa 5 ảnh về máy
    count = 0
    for item in data:
        if count >= 5:
            break
        download_image(item['id'], item.get('image_url') or DEFAULT_IMAGE_URL)
        count += 1

    conn.close()
    print("Hoàn tất lưu metadata và tải ảnh.")

def save_cat_data():
    main()
